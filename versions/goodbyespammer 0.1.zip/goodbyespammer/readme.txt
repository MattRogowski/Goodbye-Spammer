Name: Goodbye Spammer
Description: Makes it easy to delete all traces of a spammer from your forum.
Website: http://mattrogowski.co.uk
Author: MattRogowski
Authorsite: http://mattrogowski.co.uk
Version: 0.1
Compatibility: 1.6.x
Files: 2
Templates added: 4
Template changes: 1
Settings added: 4 (1 group)

Information:
This plugin adds a form to make it easy to remove everything a spammer may have added to your forum.

Includes an admin configurable option for whether spammers should be banned or deleted, and has a setting to stop the tool being used on people with more than a certain amount of posts.

Includes the ability to submit information on the spammer to the StopForumSpam database.

To Install:
Upload ./inc/plugins/goodbyespammer.php to ./inc/plugins/
Upload ./inc/languages/english/goodbyespammer.lang.php to ./inc/lenguages/english/
Go to ACP > Plugins > Activate
Go to ACP > Configuration > Goodbye Spammer Settings > Configure settings > Save.

Change Log:
09/03/11 - v0.1 -> Initial 'beta' release.

Copyright 2010 Matthew Rogowski

 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at

 ** http://www.apache.org/licenses/LICENSE-2.0

 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.